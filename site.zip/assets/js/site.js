/* BRASIS · comportamento geral do site */
(function () {
  "use strict";
  var d = document, html = d.documentElement;

  // Cabeçalho: transparente no topo, sólido durante a rolagem
  var cab = d.querySelector("[data-cabecalho]");
  if (cab) {
    var atualizar = function () { cab.classList.toggle("cabecalho--rolado", window.scrollY > 24); };
    atualizar();
    window.addEventListener("scroll", atualizar, { passive: true });
  }

  // Menu móvel
  var botao = d.querySelector("[data-menu-botao]"), menu = d.querySelector("[data-menu]");
  if (botao && menu) {
    var abrir = function (sim) {
      botao.setAttribute("aria-expanded", sim ? "true" : "false");
      menu.hidden = !sim;
      html.classList.toggle("menu-aberto", sim);
      botao.querySelector(".menu-botao__texto").textContent = sim ? "Fechar" : "Menu";
      if (sim) { var a = menu.querySelector("a"); if (a) a.focus(); }
    };
    botao.addEventListener("click", function () { abrir(menu.hidden); });
    menu.addEventListener("click", function (e) { if (e.target.closest("a")) abrir(false); });
    d.addEventListener("keydown", function (e) {
      if (e.key === "Escape" && !menu.hidden) { abrir(false); botao.focus(); }
    });
    window.addEventListener("resize", function () { if (window.innerWidth > 1080 && !menu.hidden) abrir(false); });
  }

  // Logotipo: descritor com a largura exata do nome
  function ajustarLockup(box) {
    var nome = box.querySelector(".lockup__nome"), desc = box.querySelector(".lockup__desc");
    if (!nome || !desc) return;
    desc.style.letterSpacing = "0px"; desc.style.marginRight = "0px"; desc.style.fontSize = "";
    var lsNome = parseFloat(getComputedStyle(nome).letterSpacing) || 0;
    nome.style.marginRight = -lsNome + "px";
    var alvo = nome.getBoundingClientRect().width - lsNome;
    var larg = desc.getBoundingClientRect().width;
    if (!alvo || !larg) return;
    if (larg > alvo) {
      var fs = parseFloat(getComputedStyle(desc).fontSize);
      desc.style.fontSize = (fs * alvo / larg * 0.94) + "px";
      larg = desc.getBoundingClientRect().width;
    }
    var ls = (alvo - larg) / (desc.textContent.length - 1);
    desc.style.letterSpacing = ls + "px";
    desc.style.marginRight = -ls + "px";
  }
  function lockups() { [].forEach.call(d.querySelectorAll("[data-lockup]"), ajustarLockup); }
  if (d.fonts && d.fonts.ready) d.fonts.ready.then(lockups);
  lockups();

  // Filtro de categorias nas análises
  var filtros = d.querySelector("[data-filtros]");
  if (filtros) {
    var cards = [].slice.call(d.querySelectorAll("[data-categoria]"));
    var vazio = d.querySelector("[data-filtro-vazio]");
    filtros.addEventListener("click", function (e) {
      var b = e.target.closest("button[data-filtro]"); if (!b) return;
      var f = b.getAttribute("data-filtro"), n = 0;
      [].forEach.call(filtros.querySelectorAll("button"), function (x) { x.setAttribute("aria-pressed", x === b ? "true" : "false"); });
      cards.forEach(function (c) { var ok = f === "todas" || c.getAttribute("data-categoria") === f; c.hidden = !ok; if (ok) n++; });
      if (vazio) vazio.hidden = n > 0;
    });
  }

  // Copiar endereço / link
  [].forEach.call(d.querySelectorAll("[data-copiar]"), function (b) {
    b.addEventListener("click", function () {
      var texto = b.getAttribute("data-copiar");
      var aviso = b.parentNode.querySelector("[data-copiado]");
      var mostrar = function (msg) { if (aviso) { aviso.textContent = msg; aviso.hidden = false; setTimeout(function () { aviso.hidden = true; }, 2600); } };
      try {
        navigator.clipboard.writeText(texto).then(function () { mostrar("Copiado"); }, function () { mostrar("Não foi possível copiar. Selecione o texto e copie."); });
      } catch (e) { mostrar("Não foi possível copiar. Selecione o texto e copie."); }
    });
  });

  // Barra de leitura nos artigos
  var barra = d.querySelector("[data-progresso]"), artigo = d.querySelector("[data-artigo]");
  if (barra && artigo) {
    var prog = function () {
      var r = artigo.getBoundingClientRect(), total = r.height - window.innerHeight;
      var p = total > 0 ? Math.min(1, Math.max(0, -r.top / total)) : 1;
      barra.style.transform = "scaleX(" + p.toFixed(3) + ")";
    };
    prog(); window.addEventListener("scroll", prog, { passive: true });
  }
})();
