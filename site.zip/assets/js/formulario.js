/* BRASIS · envio do formulário de contato (compatível com Formspree).
   Só mostra sucesso quando o serviço confirma o recebimento. */
(function () {
  "use strict";
  var form = document.querySelector("[data-formulario]");
  if (!form) return;
  var status = form.querySelector("[data-status]");
  var botao = form.querySelector("button[type=submit]");

  function mostrar(tipo, msg) {
    status.hidden = false;
    status.className = "formulario__status formulario__status--" + tipo;
    status.textContent = msg;
  }

  form.addEventListener("submit", function (e) {
    e.preventDefault();
    if (!form.checkValidity()) {
      var invalido = form.querySelector(":invalid");
      mostrar("erro", "Confira os campos obrigatórios e o e-mail informado.");
      if (invalido) invalido.focus();
      return;
    }
    botao.disabled = true;
    var texto = botao.textContent; botao.textContent = "Enviando…";
    fetch(form.action, { method: "POST", body: new FormData(form), headers: { Accept: "application/json" } })
      .then(function (r) {
        if (r.ok) {
          form.reset();
          mostrar("ok", "Mensagem enviada. Obrigado pelo contato.");
        } else {
          return r.json().catch(function () { return {}; }).then(function () {
            mostrar("erro", "Não foi possível enviar agora. Tente de novo ou escreva para contato@brasisestrategia.com.br.");
          });
        }
      })
      .catch(function () { mostrar("erro", "Sem conexão com o serviço de envio. Tente de novo ou use o WhatsApp ou o e-mail."); })
      .then(function () { botao.disabled = false; botao.textContent = texto; });
  });
})();
