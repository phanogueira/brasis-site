/* BRASIS · Abertura: do território ao símbolo.
   Cenas: 1 território (traçado do contorno) · 2 fragmentação (corte em quadrantes) ·
   3 transformação (morfose de cada fragmento em um quarto de círculo) · 4 símbolo · 5 assinatura.
   Duração: cerca de 10 segundos, com contador regressivo. Clicar em qualquer lugar, no botão
   ou pressionar Esc/Enter/Espaço entra no site na hora.
   Versões: completa; leve (celular/equipamento modesto, menos pontos na morfose); abreviada
   para visitante recorrente (desligada por padrão, ver ABREVIAR_RECORRENTES);
   sem animação quando o sistema pede movimento reduzido (tratado no <head>). */
(function () {
  "use strict";
  var html = document.documentElement;
  var palco = document.querySelector("[data-abertura]");
  var pular = document.querySelector("[data-abertura-pular]");
  if (!palco) return;

  function remover() {
    if (palco.parentNode) palco.parentNode.removeChild(palco);
    if (pular && pular.parentNode) pular.parentNode.removeChild(pular);
    html.classList.remove("abertura-ativa", "abertura-rodando");
  }
  if (!html.classList.contains("abertura-ativa")) { remover(); return; }
  html.classList.add("abertura-rodando");

  var DURACAO = 10000;            // duração total em ms (contador de 10 s)
  var ABREVIAR_RECORRENTES = false; // true = quem voltou em até 30 dias vê só a assinatura
  var recorrente = false;
  try {
    var visto = window.localStorage.getItem("brasis-abertura");
    recorrente = ABREVIAR_RECORRENTES && !!visto && Date.now() - Number(visto) < 30 * 864e5;
    window.localStorage.setItem("brasis-abertura", String(Date.now()));
  } catch (e) { /* armazenamento indisponível: segue com a versão completa */ }

  var leve = window.innerWidth < 640 ||
    (navigator.hardwareConcurrency && navigator.hardwareConcurrency <= 4) ||
    (navigator.connection && navigator.connection.saveData);
  // A coreografia foi desenhada em 5,6 s; K estica tudo para caber na duração escolhida
  var K = DURACAO / 5600;
  var numero = document.querySelector("[data-contador]");
  var anel = document.querySelector("[data-anel]");
  var CIRC = 2 * Math.PI * 16;
  if (anel) { anel.style.strokeDasharray = CIRC; anel.style.strokeDashoffset = 0; }
  function contar(t) {
    var resta = Math.max(0, DURACAO - t);
    if (numero) numero.textContent = String(Math.ceil(resta / 1000));
    if (anel) anel.style.strokeDashoffset = (CIRC * (1 - resta / DURACAO)).toFixed(2);
  }

  var mapa = palco.querySelector("[data-mapa]");
  var pecas = [].slice.call(palco.querySelectorAll("[data-peca]"));
  var guiaH = palco.querySelector(".ab-guia--h"), guiaV = palco.querySelector(".ab-guia--v"), guiaC = palco.querySelector(".ab-guia--circ");
  var DIR = { tl: [-1, -1, -7], tr: [1, -1, 6], bl: [-1, 1, 8], br: [1, 1, -5] };

  var itens = pecas.map(function (g) {
    var forma = g.querySelector(".ab-peca__forma");
    var interp = null;
    if (window.flubber) {
      try { interp = window.flubber.interpolate(forma.getAttribute("data-de"), forma.getAttribute("data-para"), { maxSegmentLength: leve ? 6 : 3 }); }
      catch (e) { interp = null; }
    }
    return { g: g, forma: forma, restos: [].slice.call(g.querySelectorAll(".ab-peca__resto")), d: DIR[g.getAttribute("data-peca")] || [0, 0, 0], interp: interp };
  });

  function prep(el) { var L = el.getTotalLength ? el.getTotalLength() : 1000; el.style.strokeDasharray = L; el.style.strokeDashoffset = L; return L; }
  var Lm = prep(mapa), Lh = prep(guiaH), Lv = prep(guiaV), Lc = prep(guiaC);

  var clamp = function (x) { return x < 0 ? 0 : x > 1 ? 1 : x; };
  var easeOut = function (t) { return 1 - Math.pow(1 - t, 3); };
  var easeIO = function (t) { return t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2; };
  var fase = function (t, a, b) { return clamp((t - a * K) / ((b - a) * K)); };

  var raf = null, inicio = null, terminou = false;

  function estadoFinal() {
    mapa.style.opacity = 0;
    [guiaH, guiaV, guiaC].forEach(function (g) { g.style.opacity = 0; });
    itens.forEach(function (it) {
      it.g.style.opacity = 1;
      it.g.style.transform = "none";
      it.forma.setAttribute("d", it.forma.getAttribute("data-para"));
      it.restos.forEach(function (r) { r.style.opacity = 0; });
    });
    palco.classList.add("assinar");
  }

  function sair(rapido) {
    if (terminou) return; terminou = true;
    if (raf) cancelAnimationFrame(raf);
    palco.classList.add("saindo");
    html.classList.add("abertura-fim");
    window.setTimeout(remover, rapido ? 450 : 950);
  }

  function quadro(agora) {
    if (inicio === null) inicio = agora;
    var t = agora - inicio;
    contar(t);

    // Cena 1 — território
    mapa.style.strokeDashoffset = Lm * (1 - easeIO(fase(t, 0, 1300)));
    mapa.style.fillOpacity = easeOut(fase(t, 900, 1650));

    // Cena 2 — fragmentação: linhas de corte e afastamento dos quadrantes
    guiaH.style.strokeDashoffset = Lh * (1 - easeOut(fase(t, 1450, 2050)));
    guiaV.style.strokeDashoffset = Lv * (1 - easeOut(fase(t, 1600, 2200)));
    guiaC.style.strokeDashoffset = Lc * (1 - easeIO(fase(t, 2300, 3300)));
    var troca = t >= 2150 * K;
    mapa.style.opacity = troca ? 0 : 1;
    var sep = easeOut(fase(t, 2150, 2850));
    var morf = easeIO(fase(t, 2850, 4150));
    var dist = 15 * sep * (1 - morf);

    itens.forEach(function (it) {
      it.g.style.opacity = troca ? 1 : 0;
      var rot = it.d[2] * sep * (1 - morf);
      it.g.style.transform = "translate(" + (it.d[0] * dist).toFixed(2) + "px," + (it.d[1] * dist).toFixed(2) + "px) rotate(" + rot.toFixed(2) + "deg)";
      it.restos.forEach(function (r) { r.style.opacity = 1 - fase(t, 2150, 2650); });
      // Cena 3 — transformação
      if (morf > 0) {
        if (it.interp) it.forma.setAttribute("d", it.interp(morf));
        else if (morf > 0.5) it.forma.setAttribute("d", it.forma.getAttribute("data-para"));
      }
    });

    // Cena 4 — símbolo: as guias se recolhem
    var recolhe = 1 - fase(t, 3900, 4500);
    guiaH.style.opacity = recolhe; guiaV.style.opacity = recolhe; guiaC.style.opacity = recolhe;

    // Cena 5 — assinatura
    if (t >= 4250 * K) palco.classList.add("assinar");
    if (t >= DURACAO) { contar(DURACAO); sair(false); return; }
    raf = requestAnimationFrame(quadro);
  }

  function pularAgora() { estadoFinal(); sair(true); }
  if (pular) pular.addEventListener("click", pularAgora);
  palco.addEventListener("click", pularAgora);
  document.addEventListener("keydown", function (e) { if (!terminou && (e.key === "Escape" || e.key === "Enter" || e.key === " ")) pularAgora(); });

  if (recorrente) {
    // Abreviada: o símbolo já formado e a assinatura, depois a página
    palco.classList.add("abreviada");
    estadoFinal();
    window.setTimeout(function () { sair(false); }, 1100);
    return;
  }
  raf = requestAnimationFrame(quadro);
})();
