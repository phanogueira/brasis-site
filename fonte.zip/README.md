# Site da BRASIS — Estratégia, Inteligência e Negócios

Site institucional estático para **brasisestrategia.com.br**, feito com [Eleventy](https://www.11ty.dev/).
O conteúdo fica em arquivos de texto (Markdown e JSON). O site é gerado em HTML puro, sem banco de dados e sem custo de servidor.

---

## 1. O que existe no site

| Página | Endereço | Arquivo |
|---|---|---|
| Início, com a abertura animada | `/` | `src/index.njk` |
| Quem somos | `/quem-somos/` | `src/quem-somos.njk` |
| Áreas de atuação | `/atuacao/` | `src/atuacao/index.njk` |
| Uma página por frente (4) | `/atuacao/<frente>/` | `src/atuacao/frente.njk` + `src/_data/pilares.json` |
| Radar BRASIS | `/radar/` | `src/radar.njk` |
| Análises e perspectivas | `/analises/` | `src/analises/index.njk` |
| Cada análise | `/analises/<nome-do-arquivo>/` | `src/analises/*.md` |
| Projetos, oportunidades e iniciativas | `/projetos/` | `src/projetos.njk` + `src/projetos/*.md` |
| Contato | `/contato/` | `src/contato.njk` |
| Política de privacidade | `/privacidade/` | `src/privacidade.njk` |
| Página não encontrada | `/404.html` | `src/404.njk` |
| Painel de publicação | `/admin/` | `src/admin/` |

Também são gerados `sitemap.xml`, `robots.txt`, metadados Open Graph, dados estruturados (schema.org) e favicons.

### Onde mudar cada coisa

- **Contatos, CNPJ, formulário, exemplos, foto da abertura:** `src/_data/site.json`
- **Pilares e serviços:** `src/_data/pilares.json`
- **Categorias editoriais:** `src/_data/editorial.json`
- **Cores, tipografia e layout:** `src/assets/css/site.css` (tokens no início do arquivo)
- **Abertura animada:** `src/assets/js/abertura.js` e `src/_includes/partials/abertura.njk`

---

## 2. Rodar no computador

Requer [Node.js](https://nodejs.org/) 20 ou mais recente.

```bash
npm install
npm run serve      # abre em http://localhost:8080 e atualiza a cada alteração
npm run build      # gera o site final na pasta _site/
```

Scripts auxiliares, que só precisam rodar quando a base mudar:

```bash
npm run geo                       # recria a silhueta do Brasil da abertura (src/_data/geo.json)
python3 scripts/gerar-imagens.py  # recria favicons e a imagem de compartilhamento (requer Playwright)
python3 scripts/testar.py         # testa console, links, rolagem horizontal e a abertura (requer Playwright)
```

---

## 3. Publicar

Os dois caminhos são gratuitos. Antes de mexer no DNS, **anote todos os registros atuais do domínio**, principalmente os do e-mail no UOL (MX, SPF/TXT e DKIM). Se eles forem perdidos, o e-mail `contato@brasisestrategia.com.br` para de funcionar.

### Passo comum: colocar o projeto no GitHub

1. Crie uma conta no GitHub, se ainda não tiver.
2. Crie um repositório privado chamado `brasis-site`.
3. Envie esta pasta para o repositório. Pode ser pelo GitHub Desktop ou pela opção "Upload files" do site.

### Opção A — Cloudflare Pages (recomendada)

1. Em dash.cloudflare.com, abra **Workers & Pages → Create → Pages → Connect to Git** e escolha o repositório.
2. Configure assim: *Build command* `npm run build`, *Build output directory* `_site` e a variável de ambiente `NODE_VERSION` = `22`.
3. Em **Custom domains**, adicione `brasisestrategia.com.br` e `www.brasisestrategia.com.br`.
4. Para usar o domínio sem "www", o DNS do domínio precisa estar no Cloudflare:
   - Adicione o domínio ao Cloudflare. Ele importa os registros existentes.
   - **Confira se os registros MX, SPF e DKIM do UOL foram importados.** Se faltar algum, recrie-o.
   - No Registro.br, troque os servidores DNS pelos dois que o Cloudflare indicar.
5. Depois de publicado, envie e-mails de teste nos dois sentidos para confirmar que o e-mail continua funcionando.

O arquivo `.github/workflows/github-pages.yml` só é usado na opção B e pode ser apagado.

### Opção B — GitHub Pages

1. No repositório, abra **Settings → Pages** e, em *Source*, escolha **GitHub Actions**. O fluxo incluído publica o site a cada alteração.
2. Em **Settings → Pages → Custom domain**, informe `brasisestrategia.com.br` e marque *Enforce HTTPS* quando estiver disponível.
3. No DNS atual, sem trocar de provedor:
   - Crie quatro registros **A** para `@`: `185.199.108.153`, `185.199.109.153`, `185.199.110.153` e `185.199.111.153`.
   - Crie um **CNAME** `www` apontando para `SEU-USUARIO.github.io`.
   - **Não altere os registros MX e TXT do e-mail.**

Confira os endereços na documentação do GitHub Pages antes de configurar ("Managing a custom domain").

---

## 4. Publicar análises e artigos

Cada texto é um arquivo `.md` em `src/analises/`. O nome do arquivo vira o endereço: `src/analises/cenario-2027.md` vira `/analises/cenario-2027/`.

```markdown
---
title: Título da análise
subtitulo: Uma linha que complementa o título (opcional)
date: 2026-11-03
categoria: Regulação e políticas públicas
tipo: perspectiva          # perspectiva (artigo) ou radar (nota curta)
autor: Equipe BRASIS
resumo: Duas frases que aparecem nos cards, no Google e no compartilhamento.
capa: /assets/img/conteudo/minha-foto.jpg   # opcional; sem ela, o site gera uma capa gráfica
capaAlt: Descrição da imagem
referencias:
  - titulo: Nome da fonte
    url: https://endereco-da-fonte
rascunho: false
---

Texto em Markdown. Use ## para subtítulos e > para citações em destaque.
```

As categorias válidas estão em `src/_data/editorial.json`. O tempo de leitura, a data em português, os textos relacionados, o sitemap e os metadados são gerados sozinhos.

**Três formas de publicar:**

1. **Pelo site do GitHub:** abra `src/analises/`, clique em *Add file → Create new file* e cole o modelo acima. Ao salvar, o site é republicado em um ou dois minutos.
2. **Pelo painel `/admin/`:** é um editor visual (Sveltia CMS) com formulário, imagens e pré-visualização. Para ativá-lo:
   - Em `src/admin/config.yml`, troque `SEU-USUARIO/brasis-site` pelo repositório real.
   - Para entrar, o jeito mais simples é usar um *token pessoal* do GitHub com permissão de leitura e escrita no repositório.
   - Para ter o botão "Entrar com GitHub", é preciso publicar um pequeno serviço de autenticação. A documentação do Sveltia CMS indica um Worker gratuito do Cloudflare.
   - O painel não tem área pública de edição: só entra quem tem permissão no repositório.
3. **No computador**, criando o arquivo e enviando ao GitHub.

### Textos de exemplo

As quatro análises em `src/analises/` estão marcadas com `exemplo: true` e aparecem com o selo "Exemplo". Elas não entram no sitemap. **Antes de divulgar o site, apague esses arquivos** ou mude `"mostrarExemplos"` para `false` em `site.json`.

### Projetos e oportunidades

Use `src/projetos/modelo-de-projeto.md` como modelo. Enquanto `rascunho: true`, nada aparece no site. Sem projetos publicados, a página mostra uma mensagem de "em breve".

---

## 5. Formulário de contato (opcional)

O site já tem o formulário completo: validação, campo anti-spam, consentimento e mensagens de sucesso e de erro. Ele **só aparece depois de configurado**, para que nunca se mostre "mensagem enviada" sem envio real.

1. Crie uma conta no [Formspree](https://formspree.io/). O plano gratuito tem um limite mensal de envios; confira os valores atuais no site.
2. Crie um formulário com destino `contato@brasisestrategia.com.br` e copie o endereço `https://formspree.io/f/...`.
3. Cole esse endereço em `site.json → formulario.endpoint` e publique.
4. Envie uma mensagem de teste e confira a caixa de entrada e a pasta de spam.

---

## 6. Fotografias e vídeo

A rede usada para construir o site não permitia baixar bancos de imagens. Por isso, a primeira versão usa composições gráficas próprias: o padrão Cobogó com luz, ilustrações em traço e capas geradas a partir do símbolo. O site já está preparado para receber fotos reais:

- **Primeira dobra:** em `site.json → abertura`, informe `imagem` (JPG/WebP) e, se quiser, `video` (MP4 curto e sem som). O site aplica o tratamento de cor da marca.
- **Pilares:** em `pilares.json`, acrescente `"foto": "/assets/img/conteudo/arquivo.jpg"` e `"fotoAlt": "descrição"` em cada frente.
- **Análises:** campo `capa`.

Coloque os arquivos em `src/assets/img/conteudo/`. Use imagens com até 2400 px de largura, de preferência em WebP. **Use só imagens com licença de uso comprovada**: acervo próprio, fotógrafo contratado, bancos licenciados ou Wikimedia Commons, respeitando a licença e o crédito exigidos. Evite fotos de pessoas identificáveis sem autorização.

---

## 7. Pendências antes de divulgar

| Item | Onde |
|---|---|
| Substituir o símbolo pelo SVG oficial do pacote BRASIS_identidade_v1. O atual foi redesenhado a partir da especificação. | `scripts/visuais.js` (função `simbolo`), `scripts/build-geo.mjs`, `src/assets/img/` |
| Razão social e CNPJ | `site.json` |
| Revisão jurídica da política de privacidade (LGPD) | `src/privacidade.njk` |
| Apagar os textos de exemplo e publicar as primeiras análises reais | `src/analises/` |
| Fotos licenciadas, se desejado | ver seção 6 |
| Formulário (Formspree), se desejado | ver seção 5 |
| Repositório no GitHub, hospedagem e DNS, preservando o e-mail do UOL | ver seção 3 |
| Cadastrar o site no Google Search Console e enviar o `sitemap.xml` | após publicar |
| LinkedIn institucional, quando existir | `site.json` e `src/_includes/partials/rodape.njk` |

---

## 8. Créditos e licenças

- **Archivo** (Omnibus-Type), SIL Open Font License, incluída na pasta `src/assets/fonts/`.
- **Contorno do Brasil:** Natural Earth (domínio público), via o pacote `world-atlas`.
- **flubber** (Noah Veltman), licença MIT: transição entre formas na abertura.
- **Ícones de WhatsApp e Instagram:** Simple Icons (CC0). As marcas pertencem aos respectivos titulares.
- **Sveltia CMS**, licença MIT: painel de publicação.
