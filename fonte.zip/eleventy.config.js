// Configuração do Eleventy (gerador de site estático).
// Conteúdo em Markdown/Nunjucks em src/, saída em _site/.
// PREVIEW=1 gera links relativos com index.html explícito (usado só para a prévia no Claude).
import path from "node:path";
import { capa, ilustracao, simbolo } from "./scripts/visuais.js";

const PREVIEW = process.env.PREVIEW === "1";

export default function (eleventyConfig) {
  eleventyConfig.addPassthroughCopy({ "src/assets": "assets" });
  eleventyConfig.addPassthroughCopy({ "src/admin/config.yml": "admin/config.yml" });
  eleventyConfig.addPassthroughCopy({ "src/static": "/" });

  // Datas em português
  const meses = ["janeiro", "fevereiro", "março", "abril", "maio", "junho", "julho", "agosto", "setembro", "outubro", "novembro", "dezembro"];
  const asDate = (d) => (d instanceof Date ? d : new Date(d));
  eleventyConfig.addFilter("dataLonga", (d) => { const x = asDate(d); return `${x.getUTCDate()} de ${meses[x.getUTCMonth()]} de ${x.getUTCFullYear()}`; });
  eleventyConfig.addFilter("dataCurta", (d) => { const x = asDate(d); return `${String(x.getUTCDate()).padStart(2, "0")}.${String(x.getUTCMonth() + 1).padStart(2, "0")}.${x.getUTCFullYear()}`; });
  eleventyConfig.addFilter("dataISO", (d) => asDate(d).toISOString());

  // Tempo de leitura (220 palavras por minuto)
  eleventyConfig.addFilter("leitura", (html = "") => {
    const palavras = String(html).replace(/<[^>]+>/g, " ").split(/\s+/).filter(Boolean).length;
    return Math.max(1, Math.round(palavras / 220));
  });

  eleventyConfig.addFilter("encode", (s) => encodeURIComponent(s || ""));
  eleventyConfig.addFilter("json", (v) => JSON.stringify(v));
  eleventyConfig.addFilter("limit", (arr, n) => (arr || []).slice(0, n));
  eleventyConfig.addFilter("exceto", (arr, url) => (arr || []).filter((i) => i.url !== url));
  eleventyConfig.addFilter("doTipo", (arr, tipo) => (arr || []).filter((i) => i.data.tipo === tipo));
  eleventyConfig.addFilter("porCategoria", (arr, cat) => (arr || []).filter((i) => i.data.categoria === cat));

  // URL: absoluta no site real; relativa na prévia
  eleventyConfig.addFilter("u", function (target) {
    if (!target || /^(https?:|mailto:|tel:|#)/.test(target)) return target;
    if (!PREVIEW) return target;
    const [p, hash] = target.split("#");
    const from = (this.page && this.page.url) || "/";
    const fromDir = from.endsWith("/") ? from : path.posix.dirname(from) + "/";
    let rel = path.posix.relative(fromDir, p);
    if (p.endsWith("/")) rel = (rel ? rel + "/" : "") + "index.html";
    if (!rel) rel = "index.html";
    return rel + (hash ? "#" + hash : "");
  });

  // Análises publicadas (rascunhos ficam fora; exemplos saem se site.mostrarExemplos = false)
  eleventyConfig.addCollection("analises", (api) => {
    const site = api.getAll()[0]?.data?.site || {};
    return api.getFilteredByGlob("src/analises/*.md")
      .filter((i) => !i.data.rascunho)
      .filter((i) => site.mostrarExemplos !== false || !i.data.exemplo)
      .sort((a, b) => b.date - a.date);
  });
  eleventyConfig.addCollection("projetos", (api) =>
    api.getFilteredByGlob("src/projetos/*.md").filter((i) => !i.data.rascunho).sort((a, b) => b.date - a.date)
  );

  eleventyConfig.addShortcode("capa", capa);
  eleventyConfig.addShortcode("ilustracao", ilustracao);
  eleventyConfig.addShortcode("simbolo", simbolo);

  eleventyConfig.addGlobalData("preview", PREVIEW);
  // Versão dos arquivos: muda a cada build e obriga o navegador a baixar CSS e JS novos
  eleventyConfig.addGlobalData("versao", String(Date.now()));

  return {
    dir: { input: "src", output: "_site", includes: "_includes", data: "_data" },
    markdownTemplateEngine: "njk",
    htmlTemplateEngine: "njk",
    templateFormats: ["njk", "md", "html"],
  };
}
