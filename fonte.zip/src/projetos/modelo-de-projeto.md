---
title: Título do projeto ou da oportunidade
date: 2026-10-19
tipoProjeto: Oportunidades
situacao: Em estruturação
local: Brasil
resumo: Uma ou duas frases sobre o que é a iniciativa, para quem ela importa e em que estágio está.
rascunho: true
---

Modelo de preenchimento. Enquanto "rascunho" for true, este item não aparece no site.
Publique só com autorização dos envolvidos.
