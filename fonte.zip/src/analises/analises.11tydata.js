// Padrões para todos os textos da pasta src/analises/
import { readFileSync } from "node:fs";
export default {
  layout: "layouts/artigo.njk",
  tipo: "perspectiva",
  pagina: "artigo",
  tipoOg: "article",
  eleventyComputed: {
    permalink: (data) => {
      if (data.page.fileSlug === "analises" || data.page.inputPath.endsWith("index.njk")) return data.permalink;
      if (data.rascunho) return false; // rascunhos não geram página
      if (data.exemplo && data.site && data.site.mostrarExemplos === false) return false;
      return `/analises/${data.page.fileSlug}/`;
    },
    descricao: (data) => data.descricao || data.resumo,
    // Tempo de leitura a partir do texto do arquivo (220 palavras por minuto)
    minutosLeitura: (data) => {
      if (!data.page.inputPath.endsWith(".md")) return null;
      const bruto = readFileSync(data.page.inputPath, "utf8").replace(/^---[\s\S]*?---/, "");
      return Math.max(1, Math.round(bruto.split(/\s+/).filter(Boolean).length / 220));
    },
  },
};
