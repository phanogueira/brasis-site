---
title: "Monitoramento legislativo: o que acompanhar além do projeto de lei"
date: 2026-10-16
categoria: Relações governamentais
tipo: radar
autor: Equipe BRASIS
resumo: O texto do projeto é só uma parte da história. Emendas, pareceres, requerimentos e consultas públicas costumam sinalizar mudanças antes da votação.
exemplo: true
referencias:
  - titulo: Câmara dos Deputados — busca de proposições
    url: https://www.camara.leg.br/busca-portal/proposicoes/pesquisa-simplificada
  - titulo: Senado Federal — atividade legislativa
    url: https://www25.senado.leg.br/web/atividade
  - titulo: Diário Oficial da União — Imprensa Nacional
    url: https://www.in.gov.br/
---

**O que acontece.** Muitas organizações acompanham apenas os projetos de lei que afetam seu setor. Esse acompanhamento costuma começar tarde e olhar para o lugar errado.

**Por que importa.** A direção de uma proposta muda nas emendas, nos pareceres de comissão e nos acordos que definem a pauta. Na esfera regulatória, normas infralegais, como portarias, resoluções e instruções normativas, alteram obrigações sem passar pelo Legislativo.

## O que observar

- **Emendas e substitutivos**, que podem mudar o alcance de um texto.
- **Pareceres e designação de relatores**, que indicam a orientação provável da comissão.
- **Requerimentos de urgência**, que encurtam prazos e reduzem a janela de diálogo.
- **Audiências públicas**, que mostram quais argumentos e atores estão em cena.
- **Consultas públicas de agências e ministérios**, abertas a contribuições formais.
- **Publicações no Diário Oficial**, inclusive nos estados e municípios relevantes para o negócio.

## O que fazer com isso

Monitorar é transformar sinais em alertas com contexto: o que mudou, qual o impacto provável e qual o próximo passo legítimo, seja uma contribuição técnica, uma nota de posicionamento ou a revisão de um plano.
