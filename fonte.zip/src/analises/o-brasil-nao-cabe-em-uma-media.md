---
title: O Brasil não cabe em uma média
subtitulo: Indicadores nacionais escondem as diferenças que mais importam para quem investe e decide.
date: 2026-10-07
categoria: Desenvolvimento regional
tipo: perspectiva
autor: Equipe BRASIS
resumo: Médias nacionais são úteis para manchetes e pouco úteis para decisões. Entrar em um mercado, escolher um parceiro ou desenhar uma política pede leitura regional.
exemplo: true
referencias:
  - titulo: IBGE — Contas Regionais do Brasil
    url: https://www.ibge.gov.br/estatisticas/economicas/contas-nacionais/9054-contas-regionais-do-brasil.html
  - titulo: IBGE — Produto Interno Bruto dos Municípios
    url: https://www.ibge.gov.br/estatisticas/economicas/contas-nacionais/9088-produto-interno-bruto-dos-municipios.html
  - titulo: Ipeadata — base de dados do Instituto de Pesquisa Econômica Aplicada
    url: http://www.ipeadata.gov.br/
---

Quando se fala do Brasil, fala-se quase sempre de médias: crescimento médio, renda média, inflação média. Esses números contam uma história verdadeira e incompleta. O país é formado por economias regionais com dinâmicas próprias de produção, consumo, emprego e relação com o poder público.

## A média esconde a decisão

Uma empresa que avalia expandir operações raramente decide "entrar no Brasil". Ela decide entre estados, regiões metropolitanas e cidades médias. Nessa escala, as diferenças de infraestrutura, mão de obra, arranjo institucional e ambiente regulatório local pesam mais do que qualquer indicador nacional.

> Decidir no Brasil é decidir em um território específico, com instituições específicas.

## Três camadas para olhar

**Economia.** Que setores sustentam a região, para onde a produção escoa e quais cadeias estão em expansão.

**Instituições.** Como funcionam o governo estadual, as prefeituras, as agências e os órgãos de controle que afetam o projeto, e como se relacionam entre si.

**Atores.** Quem lidera as entidades empresariais, as universidades e as organizações locais com capacidade de apoiar ou travar uma iniciativa.

## Fontes que ajudam

O IBGE publica as Contas Regionais e o PIB dos Municípios, que permitem comparar estrutura produtiva entre estados e cidades. O Ipeadata reúne séries econômicas e sociais em diferentes recortes territoriais. São pontos de partida. A leitura completa exige combiná-los com informação qualitativa sobre instituições e pessoas.

## O que isso muda na prática

Projetos bem desenhados partem de uma pergunta territorial: onde, com quem e sob quais regras. Responder a ela antes de comprometer recursos reduz risco e revela oportunidades que a média nacional não mostra.
