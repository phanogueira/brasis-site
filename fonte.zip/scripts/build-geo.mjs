// Gera a geometria da abertura: silhueta real do Brasil (Natural Earth 1:50m, via world-atlas),
// dividida em quatro quadrantes que se transformam nos quatro quartos de círculo do símbolo.
// Uso: node scripts/build-geo.mjs  →  src/_data/geo.json
import { readFileSync, writeFileSync } from "node:fs";
import { feature } from "topojson-client";
import polygonClipping from "polygon-clipping";

const topo = JSON.parse(readFileSync(new URL("../node_modules/world-atlas/countries-50m.json", import.meta.url)));
const countries = feature(topo, topo.objects.countries);
const brasil = countries.features.find((f) => f.id === "076");
if (!brasil) throw new Error("Brasil não encontrado no world-atlas");

// Maior polígono (território continental). Ilhas oceânicas ficam de fora da silhueta.
const polys = brasil.geometry.type === "MultiPolygon" ? brasil.geometry.coordinates : [brasil.geometry.coordinates];
const area = (ring) => Math.abs(ring.reduce((s, [x1, y1], i) => { const [x2, y2] = ring[(i + 1) % ring.length]; return s + (x1 * y2 - x2 * y1); }, 0) / 2);
const continente = polys.slice().sort((a, b) => area(b[0]) - area(a[0]))[0][0];

// Projeção equiretangular com correção de latitude média (~-14°)
const lat0 = -14 * Math.PI / 180;
const proj = ([lon, lat]) => [lon * Math.cos(lat0), -lat];
let pts = continente.map(proj);

// Simplificação Ramer–Douglas–Peucker
function rdp(points, eps) {
  if (points.length < 3) return points;
  const [a, b] = [points[0], points[points.length - 1]];
  let maxD = 0, idx = 0;
  for (let i = 1; i < points.length - 1; i++) {
    const [x, y] = points[i];
    const num = Math.abs((b[1] - a[1]) * x - (b[0] - a[0]) * y + b[0] * a[1] - b[1] * a[0]);
    const den = Math.hypot(b[1] - a[1], b[0] - a[0]) || 1;
    const d = num / den;
    if (d > maxD) { maxD = d; idx = i; }
  }
  if (maxD > eps) return [...rdp(points.slice(0, idx + 1), eps).slice(0, -1), ...rdp(points.slice(idx), eps)];
  return [a, b];
}
// anel fechado: remove o ponto repetido e simplifica em duas metades
if (pts[0][0] === pts.at(-1)[0] && pts[0][1] === pts.at(-1)[1]) pts = pts.slice(0, -1);
{
  const half = Math.floor(pts.length / 2);
  const a = rdp(pts.slice(0, half + 1), 0.06), b = rdp([...pts.slice(half), pts[0]], 0.06);
  pts = [...a.slice(0, -1), ...b.slice(0, -1)];
}

// Encaixa no palco 300 × 300, com o centro do retângulo envolvente no centro do palco
const STAGE = 300, FIT = 250;
const xs = pts.map((p) => p[0]), ys = pts.map((p) => p[1]);
const [minX, maxX, minY, maxY] = [Math.min(...xs), Math.max(...xs), Math.min(...ys), Math.max(...ys)];
const s = FIT / Math.max(maxX - minX, maxY - minY);
const cx = (minX + maxX) / 2, cy = (minY + maxY) / 2;
const map = pts.map(([x, y]) => [STAGE / 2 + (x - cx) * s, STAGE / 2 + (y - cy) * s]);

const r2 = (n) => Math.round(n * 100) / 100;
const toPath = (ring) => "M" + ring.map(([x, y]) => `${r2(x)} ${r2(y)}`).join("L") + "Z";

// Quadrantes: corte em cruz pelo centro do palco
const C = STAGE / 2, BIG = 1000;
const quad = {
  tl: [[[-BIG, -BIG], [C, -BIG], [C, C], [-BIG, C], [-BIG, -BIG]]],
  tr: [[[C, -BIG], [BIG, -BIG], [BIG, C], [C, C], [C, -BIG]]],
  bl: [[[-BIG, C], [C, C], [C, BIG], [-BIG, BIG], [-BIG, C]]],
  br: [[[C, C], [BIG, C], [BIG, BIG], [C, BIG], [C, C]]],
};
const mapPoly = [[...map, map[0]]];

// Símbolo final: quatro quartos de círculo, raio 12,5 g, intervalo g. Lado total 26 g.
const SIDE = 132, g = SIDE / 26, r = 12.5 * g, o = C - SIDE / 2;
const q = (x, y) => [r2(o + x * g), r2(o + y * g)];
const R = r2(r);
const quarter = {
  // curva para noroeste: centro no canto inferior direito da célula
  tl: (() => { const [cx_, cy_] = q(12.5, 12.5), [x0] = q(0, 0), [, y0] = q(0, 0); return `M${cx_} ${cy_}L${x0} ${cy_}A${R} ${R} 0 0 1 ${cx_} ${y0}Z`; })(),
  // curva para sudeste: centro no canto superior esquerdo da célula
  tr: (() => { const [cx_, cy_] = q(13.5, 0), [x1] = q(26, 0), [, y1] = q(0, 12.5); return `M${cx_} ${cy_}L${x1} ${cy_}A${R} ${R} 0 0 1 ${cx_} ${y1}Z`; })(),
  bl: (() => { const [cx_, cy_] = q(12.5, 26), [x0] = q(0, 0), [, y0] = q(0, 13.5); return `M${cx_} ${cy_}L${x0} ${cy_}A${R} ${R} 0 0 1 ${cx_} ${y0}Z`; })(),
  br: (() => { const [cx_, cy_] = q(13.5, 13.5), [x1] = q(26, 0), [, y1] = q(0, 26); return `M${cx_} ${cy_}L${x1} ${cy_}A${R} ${R} 0 0 1 ${cx_} ${y1}Z`; })(),
};

const pieces = {};
for (const k of Object.keys(quad)) {
  const res = polygonClipping.intersection(mapPoly, quad[k]);
  const rings = res.map((p) => p[0].slice(0, -1)).sort((a, b) => area(b) - area(a));
  pieces[k] = { main: toPath(rings[0]), extra: rings.slice(1).filter((rg) => area(rg) > 4).map(toPath), quarter: quarter[k] };
}

const out = { stage: STAGE, center: C, symbolSide: SIDE, map: toPath(map), pieces, points: map.length };
writeFileSync(new URL("../src/_data/geo.json", import.meta.url), JSON.stringify(out));
console.log(`Brasil: ${map.length} pontos. Quadrantes:`, Object.fromEntries(Object.entries(pieces).map(([k, v]) => [k, 1 + v.extra.length])));
