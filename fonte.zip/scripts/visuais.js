// Ilustrações e capas geradas em SVG, a partir do sistema gráfico da marca.
// Regras do símbolo: quartos de círculo com curvas só para noroeste (NW) e sudeste (SE).
import { readFileSync } from "node:fs";

const geo = JSON.parse(readFileSync(new URL("../src/_data/geo.json", import.meta.url)));

// hash determinístico (FNV-1a) para variar composições sem aleatoriedade
function hash(str) {
  let h = 2166136261;
  for (const c of String(str)) { h ^= c.charCodeAt(0); h = Math.imul(h, 16777619); }
  return () => { h ^= h << 13; h ^= h >>> 17; h ^= h << 5; return ((h >>> 0) % 10000) / 10000; };
}

// quarto de círculo dentro da célula (x, y, lado s). dir: "nw" ou "se"
function quarto(x, y, s, dir) {
  if (dir === "nw") return `M${x + s} ${y + s}H${x}A${s} ${s} 0 0 1 ${x + s} ${y}Z`;
  return `M${x} ${y}H${x + s}A${s} ${s} 0 0 1 ${x} ${y + s}Z`;
}
// módulo BRASIS (2×2) com origem (x, y), unidade g
const MOD = [["nw", 0, 0], ["se", 13.5, 0], ["nw", 0, 13.5], ["se", 13.5, 13.5]];

const ACENTOS = {
  "Política e instituições": "#AD8B58",
  "Economia e negócios": "#D9CBB4",
  "Relações governamentais": "#F4F0E6",
  "Regulação e políticas públicas": "#52745B",
  "Desenvolvimento regional": "#AD8B58",
  "Infraestrutura e investimentos": "#D9CBB4",
  "Cultura, eventos e projetos incentivados": "#C9A46B",
  "Cenários e tendências": "#F4F0E6",
};

// Capa editorial: parede de cobogó com vazados e poucos módulos de destaque
export function capa(chave = "", categoria = "", rotulo = "") {
  const rnd = hash(chave + categoria);
  const W = 480, H = 300, g = 2.4, passo = 27 * g;
  const acento = ACENTOS[categoria] || "#AD8B58";
  const cols = Math.ceil(W / passo) + 1, rows = Math.ceil(H / passo) + 1;
  const offX = -rnd() * passo * 0.6, offY = -rnd() * passo * 0.6;
  let base = "", destaque = "";
  const alvo = Math.floor(rnd() * cols * rows);
  for (let r = 0; r < rows; r++) for (let c = 0; c < cols; c++) {
    const ox = offX + c * passo, oy = offY + r * passo, i = r * cols + c;
    MOD.forEach(([d, mx, my], q) => {
      const p = quarto(ox + mx * g, oy + my * g, 12.5 * g, d);
      if (i === alvo || (i === alvo + 1 && q % 2 === 0)) destaque += p;
      else if (rnd() > 0.16) base += p;
    });
  }
  const id = "c" + Math.floor(rnd() * 1e8);
  return `<svg class="capa-svg" viewBox="0 0 ${W} ${H}" preserveAspectRatio="xMidYMid slice" role="img" aria-label="${rotulo || "Capa gráfica: " + categoria}">
<defs><linearGradient id="${id}" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#1D4639"/><stop offset="1" stop-color="#173D32"/></linearGradient></defs>
<rect width="${W}" height="${H}" fill="#173D32"/><path d="${base}" fill="url(#${id})" opacity=".95"/><path d="${base}" fill="none" stroke="#24513F" stroke-width=".6"/><path d="${destaque}" fill="${acento}"/></svg>`;
}

const GRADE = (w, h, p) => {
  let d = "";
  for (let x = p; x < w; x += p) d += `M${x} 0V${h}`;
  for (let y = p; y < h; y += p) d += `M0 ${y}H${w}`;
  return `<path class="il-grade" d="${d}"/>`;
};

export function ilustracao(tipo) {
  const W = 600, H = 450;
  const abre = (rotulo) => `<svg class="ilustracao il-${tipo}" viewBox="0 0 ${W} ${H}" role="img" aria-label="${rotulo}">`;
  if (tipo === "cenarios") {
    return abre("Ilustração: trajetória histórica que se abre em três cenários a partir do presente") + GRADE(W, H, 50) +
      `<path class="il-linha" d="M40 330L80 318L110 326L150 300L190 308L230 288L262 290"/>
<path class="il-tracejado" d="M262 260V400"/>
<text class="il-texto" x="270" y="396">HOJE</text>
<path class="il-linha" stroke-dasharray="4 6" d="M262 290C360 280 440 190 560 120"/>
<path class="il-destaque" d="M262 290C360 286 450 250 560 236"/>
<path class="il-linha" stroke-dasharray="4 6" d="M262 290C360 300 450 350 560 380"/>
<circle class="il-ponto" cx="262" cy="290" r="5"/>
<circle class="il-no" cx="560" cy="120" r="4"/><circle class="il-no-destaque" cx="560" cy="236" r="6"/><circle class="il-no" cx="560" cy="380" r="4"/>
<text class="il-texto" x="500" y="108">CENÁRIO A</text><text class="il-texto il-texto-destaque" x="500" y="224">CENÁRIO BASE</text><text class="il-texto" x="500" y="406">CENÁRIO C</text></svg>`;
  }
  if (tipo === "atores") {
    const c = [300, 225];
    const nos = [[0.2, 1, 9], [0.95, 1, 6], [1.7, 1, 7], [2.6, 1, 5], [3.5, 1, 8], [4.4, 1, 6], [5.3, 1, 5],
      [0.55, 2, 5], [1.25, 2, 4], [2.1, 2, 6], [3.05, 2, 4], [3.95, 2, 5], [4.85, 2, 4], [5.75, 2, 6],
      [0.0, 3, 3], [0.8, 3, 4], [1.5, 3, 3], [2.4, 3, 4], [3.3, 3, 3], [4.1, 3, 4], [5.0, 3, 3], [5.9, 3, 4]];
    const pos = nos.map(([a, anel, r]) => [c[0] + Math.cos(a) * anel * 62, c[1] + Math.sin(a) * anel * 62, r]);
    const lig = [[0, 7], [0, 15], [1, 8], [2, 9], [2, 16], [4, 11], [4, 18], [5, 12], [6, 13], [7, 14], [9, 17], [11, 19], [13, 21], [3, 10]];
    let s = abre("Ilustração: mapa de atores em anéis de proximidade em torno de uma decisão");
    s += [62, 124, 186].map((r) => `<circle class="il-anel" cx="${c[0]}" cy="${c[1]}" r="${r}"/>`).join("");
    s += lig.map(([a, b]) => `<path class="il-linha-fina" d="M${pos[a][0].toFixed(1)} ${pos[a][1].toFixed(1)}L${pos[b][0].toFixed(1)} ${pos[b][1].toFixed(1)}"/>`).join("");
    s += [0, 2, 4].map((i) => `<path class="il-destaque" d="M${c[0]} ${c[1]}L${pos[i][0].toFixed(1)} ${pos[i][1].toFixed(1)}"/>`).join("");
    s += pos.map(([x, y, r], i) => `<circle class="${[0, 2, 4].includes(i) ? "il-no-destaque" : "il-no"}" cx="${x.toFixed(1)}" cy="${y.toFixed(1)}" r="${r}"/>`).join("");
    s += `<circle class="il-ponto" cx="${c[0]}" cy="${c[1]}" r="12"/><text class="il-texto" x="${c[0] - 30}" y="${c[1] + 34}">DECISÃO</text></svg>`;
    return s;
  }
  if (tipo === "instituicoes") {
    return abre("Ilustração em traço do Congresso Nacional, em Brasília") + GRADE(W, H, 50) +
      `<path class="il-linha" d="M20 318H580"/>
<path class="il-plano" d="M70 300H530V318H70Z"/>
<path class="il-linha" d="M70 300H530V318H70Z"/>
<path class="il-plano" d="M120 300A58 44 0 0 1 236 300Z"/><path class="il-linha" d="M120 300A58 44 0 0 1 236 300"/>
<path class="il-plano" d="M358 252Q434 348 510 252Z"/><path class="il-destaque" d="M358 252Q434 348 510 252Z"/>
<path class="il-plano" d="M281 300V84H297V300ZM303 300V84H319V300Z"/>
<path class="il-linha" d="M281 300V84H297V300M303 300V84H319V300"/>
<path class="il-linha" d="M297 168H303M297 176H303"/>
<path class="il-linha-fina" d="M285 100H293M285 116H293M285 132H293M285 148H293M285 188H293M285 204H293M285 220H293M285 236H293M285 252H293M285 268H293M307 100H315M307 116H315M307 132H315M307 148H315M307 188H315M307 204H315M307 220H315M307 236H315M307 252H315M307 268H315"/>
<path class="il-linha-fina" d="M90 340H510M140 356H460M200 372H400" opacity=".7"/></svg>`;
  }
  if (tipo === "parcerias") {
    const g = 8, o = [300 - 13 * g, 225 - 13 * g], sep = 46;
    const mk = ([d, mx, my]) => quarto(o[0] + mx * g + (mx > 12 ? sep : -sep), o[1] + my * g, 12.5 * g, d);
    const esq = MOD.filter(([, mx]) => mx < 12).map(mk).join("");
    const dir = MOD.filter(([, mx]) => mx > 12).map(mk).join("");
    return abre("Ilustração: as duas metades do símbolo da BRASIS ligadas por linhas de conexão") + GRADE(W, H, 50) +
      `<path class="il-plano-forte" d="${esq}"/><path class="il-plano-destaque" d="${dir}"/>
<path class="il-destaque" d="M${o[0] + 12.5 * g - sep + 6} ${o[1] + 6 * g}H${o[0] + 13.5 * g + sep - 6}M${o[0] + 12.5 * g - sep + 6} ${o[1] + 20 * g}H${o[0] + 13.5 * g + sep - 6}"/>
<circle class="il-no-destaque" cx="300" cy="${o[1] + 6 * g}" r="5"/><circle class="il-no-destaque" cx="300" cy="${o[1] + 20 * g}" r="5"/>
<path class="il-tracejado" d="M300 40V410"/></svg>`;
  }
  if (tipo === "brasil") {
    const C = geo.center, S = geo.symbolSide;
    const quarters = Object.values(geo.pieces).map((p) => p.quarter).join("");
    return `<svg class="ilustracao il-brasil" viewBox="0 0 ${geo.stage} ${geo.stage}" role="img" aria-label="Desenho técnico: o contorno do Brasil dividido em quatro quadrantes, sobreposto ao símbolo da BRASIS">
<path class="il-grade" d="M0 ${C}H${geo.stage}M${C} 0V${geo.stage}"/>
<path class="il-plano" d="${geo.map}"/><path class="il-linha" d="${geo.map}"/>
<path class="il-quartos" d="${quarters}"/>
<circle class="il-anel" cx="${C}" cy="${C}" r="${(S / 2) * 1.414}"/>
<path class="il-destaque" d="M${C - 8} ${C}H${C + 8}M${C} ${C - 8}V${C + 8}"/></svg>`;
  }
  return "";
}

// Símbolo BRASIS (unidade g = 1). reduzido: intervalo de 3 g
export function simbolo(reduzido = false, classe = "simbolo") {
  if (reduzido) return `<svg class="${classe}" viewBox="0 0 28 28" aria-hidden="true" focusable="false"><path d="M12.5 12.5H0A12.5 12.5 0 0 1 12.5 0ZM15.5 0H28A12.5 12.5 0 0 1 15.5 12.5ZM12.5 28H0A12.5 12.5 0 0 1 12.5 15.5ZM15.5 15.5H28A12.5 12.5 0 0 1 15.5 28Z"/></svg>`;
  return `<svg class="${classe}" viewBox="0 0 26 26" aria-hidden="true" focusable="false"><path d="M12.5 12.5H0A12.5 12.5 0 0 1 12.5 0ZM13.5 0H26A12.5 12.5 0 0 1 13.5 12.5ZM12.5 26H0A12.5 12.5 0 0 1 12.5 13.5ZM13.5 13.5H26A12.5 12.5 0 0 1 13.5 26Z"/></svg>`;
}
