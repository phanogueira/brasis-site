"""Testes do site gerado: console, rolagem horizontal, links internos, imagens e abertura.
Uso: npm run build && python3 scripts/testar.py [pasta_de_capturas]"""
import sys, threading, functools, re
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from pathlib import Path
from playwright.sync_api import sync_playwright

RAIZ = Path(__file__).resolve().parent.parent
SITE = RAIZ / "_site"
CAP = Path(sys.argv[1]) if len(sys.argv) > 1 else RAIZ / "_testes"
CAP.mkdir(parents=True, exist_ok=True)

handler = functools.partial(SimpleHTTPRequestHandler, directory=str(SITE))
handler.log_message = lambda *a: None
srv = ThreadingHTTPServer(("127.0.0.1", 8787), handler)
threading.Thread(target=srv.serve_forever, daemon=True).start()
BASE = "http://127.0.0.1:8787"

paginas = sorted("/" + str(p.relative_to(SITE)).replace("index.html", "") for p in SITE.rglob("index.html") if "admin" not in str(p))
problemas = []

with sync_playwright() as p:
    b = p.chromium.launch()
    for largura, altura, nome in [(1440, 900, "desk"), (390, 844, "cel")]:
        ctx = b.new_context(viewport={"width": largura, "height": altura}, reduced_motion="reduce", device_scale_factor=1)
        pg = ctx.new_page()
        erros = []
        pg.on("console", lambda m: erros.append(m.text) if m.type == "error" else None)
        pg.on("pageerror", lambda e: erros.append(str(e)))
        pg.on("requestfailed", lambda r: erros.append("falhou: " + r.url))
        pg.on("response", lambda r: erros.append(f"{r.status}: {r.url}") if r.status >= 400 else None)
        for url in paginas:
            erros.clear()
            pg.goto(BASE + url, wait_until="networkidle")
            sobra = pg.evaluate("document.documentElement.scrollWidth - window.innerWidth")
            if sobra > 0:
                largos = pg.evaluate("""() => [...document.querySelectorAll('body *')].filter(e => e.getBoundingClientRect().right > window.innerWidth + 1).slice(0,5).map(e => e.tagName + '.' + e.className)""")
                problemas.append(f"[{nome}] {url}: rolagem horizontal de {sobra}px · {largos}")
            if erros:
                problemas.append(f"[{nome}] {url}: " + " | ".join(erros))
            h1 = pg.locator("h1").count()
            if h1 != 1:
                problemas.append(f"[{nome}] {url}: {h1} elementos h1")
            if nome == "desk" or url in ("/", "/atuacao/consultoria-estrategica/", "/analises/como-ler-um-edital/", "/contato/"):
                arq = (url.strip("/").replace("/", "_") or "inicio") + f"_{nome}.png"
                pg.screenshot(path=str(CAP / arq), full_page=True)
        # links internos
        if nome == "desk":
            vistos = set()
            for url in paginas:
                pg.goto(BASE + url)
                for href in pg.eval_on_selector_all("a[href]", "els => els.map(e => e.getAttribute('href'))"):
                    if href.startswith("/") and not href.startswith("//"):
                        alvo = href.split("#")[0]
                        if alvo in vistos: continue
                        vistos.add(alvo)
                        r = pg.request.get(BASE + alvo)
                        if r.status >= 400: problemas.append(f"link quebrado em {url}: {href} ({r.status})")
        ctx.close()

    # Abertura animada: quadros da sequência
    for largura, altura, nome in [(1440, 900, "desk"), (390, 844, "cel")]:
        ctx = b.new_context(viewport={"width": largura, "height": altura})
        pg = ctx.new_page()
        erros = []
        pg.on("pageerror", lambda e: erros.append(str(e)))
        pg.goto(BASE + "/")
        for t in [700, 1500, 2500, 3300, 3900, 4800, 6800]:
            pg.wait_for_timeout(t - (pg.evaluate("performance.now()") if False else 0) if False else 0)
        # captura por tempo absoluto
        inicio = pg.evaluate("performance.now()")
        for t in [600, 1400, 2400, 3200, 3700, 4500, 6600]:
            agora = pg.evaluate("performance.now()") - inicio
            if t > agora: pg.wait_for_timeout(t - agora)
            pg.screenshot(path=str(CAP / f"abertura_{nome}_{t}.png"))
        ainda = pg.evaluate("!!document.querySelector('[data-abertura]')")
        if ainda: problemas.append(f"[{nome}] abertura ainda presente após 6,6 s")
        if erros: problemas.append(f"[{nome}] abertura: " + " | ".join(erros))
        # visitante recorrente
        pg.goto(BASE + "/")
        pg.wait_for_timeout(500)
        pg.screenshot(path=str(CAP / f"abertura_{nome}_recorrente.png"))
        pg.wait_for_timeout(1800)
        if pg.evaluate("!!document.querySelector('[data-abertura]')"): problemas.append(f"[{nome}] versão abreviada não terminou")
        ctx.close()
    b.close()
srv.shutdown()
print(f"{len(paginas)} páginas testadas.")
print("\n".join(problemas) if problemas else "Nenhum problema encontrado.")
