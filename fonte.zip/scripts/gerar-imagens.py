"""Gera favicons, símbolo em PNG e a imagem de compartilhamento (Open Graph).
Uso: python3 scripts/gerar-imagens.py  (requer Playwright com Chromium)."""
from pathlib import Path
from playwright.sync_api import sync_playwright

RAIZ = Path(__file__).resolve().parent.parent
IMG = RAIZ / "src" / "assets" / "img"
import base64
FONTE = "data:font/woff2;base64," + base64.b64encode((RAIZ / "src" / "assets" / "fonts" / "archivo-var.woff2").read_bytes()).decode()
IMG.mkdir(parents=True, exist_ok=True)

SIMB = "M12.5 12.5H0A12.5 12.5 0 0 1 12.5 0ZM13.5 0H26A12.5 12.5 0 0 1 13.5 12.5ZM12.5 26H0A12.5 12.5 0 0 1 12.5 13.5ZM13.5 13.5H26A12.5 12.5 0 0 1 13.5 26Z"
RED = "M12.5 12.5H0A12.5 12.5 0 0 1 12.5 0ZM15.5 0H28A12.5 12.5 0 0 1 15.5 12.5ZM12.5 28H0A12.5 12.5 0 0 1 12.5 15.5ZM15.5 15.5H28A12.5 12.5 0 0 1 15.5 28Z"

# Favicon vetorial: símbolo reduzido em Off-white sobre Verde Mata
favicon = f'''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 40 40"><rect width="40" height="40" rx="6" fill="#173D32"/><g transform="translate(6 6)"><path fill="#F4F0E6" d="{RED}"/></g></svg>'''
(IMG / "favicon.svg").write_text(favicon)

def icone(tam, pad, raio, reduzido=True):
    d, lado = (RED, 28) if reduzido else (SIMB, 26)
    esc = (tam - 2 * pad) / lado
    return f'''<html><body style="margin:0;background:transparent"><svg width="{tam}" height="{tam}" viewBox="0 0 {tam} {tam}">
<rect width="{tam}" height="{tam}" rx="{raio}" fill="#173D32"/>
<g transform="translate({pad} {pad}) scale({esc})"><path fill="#F4F0E6" d="{d}"/></g></svg></body></html>'''

padrao = "data:image/svg+xml," + (
    "%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 27 27'%3E%3Cpath fill='%231D4639' d='" + SIMB + "'/%3E%3C/svg%3E"
)
og = f'''<html><head><style>
@font-face {{ font-family: Archivo; src: url({FONTE}) format("woff2"); font-weight: 100 900; font-stretch: 62% 125%; }}
body {{ margin: 0; width: 1200px; height: 630px; background: #10291F; font-family: Archivo; color: #F4F0E6; position: relative; overflow: hidden; }}
.pad {{ position: absolute; inset: 0 0 0 auto; width: 640px; background-image: url("{padrao}"); background-size: 108px 108px; background-position: right top;
  -webkit-mask-image: linear-gradient(90deg, transparent, #000 60%); }}
.luz {{ position: absolute; right: -120px; top: -160px; width: 760px; height: 760px; background: radial-gradient(closest-side, rgba(201,164,107,.28), transparent); }}
.c {{ position: absolute; left: 80px; top: 76px; bottom: 70px; width: 760px; display: flex; flex-direction: column; justify-content: space-between; }}
.marca {{ display: flex; align-items: center; gap: 22px; }}
.nome {{ font-stretch: 114%; font-weight: 500; letter-spacing: .16em; font-size: 40px; line-height: 1; }}
.desc {{ font-size: 13px; font-weight: 500; letter-spacing: .34em; text-transform: uppercase; color: #AD8B58; margin-top: 10px; }}
h1 {{ margin: 0; font-stretch: 118%; font-weight: 340; font-size: 76px; line-height: 1.0; letter-spacing: -.02em; }}
.dom {{ font-size: 18px; letter-spacing: .08em; color: #D9CBB4; border-top: 1px solid rgba(173,139,88,.6); padding-top: 18px; width: 360px; }}
</style></head><body>
<div class="luz"></div><div class="pad"></div>
<div class="c">
  <div class="marca"><svg width="64" height="64" viewBox="0 0 26 26"><path fill="#F4F0E6" d="{SIMB}"/></svg>
    <div><div class="nome">BRASIS</div><div class="desc">Estratégia, Inteligência e Negócios</div></div></div>
  <h1>Inteligência para conectar os Brasis.</h1>
  <div class="dom">brasisestrategia.com.br</div>
</div></body></html>'''

with sync_playwright() as p:
    b = p.chromium.launch()
    pg = b.new_page(viewport={"width": 1200, "height": 630})
    pg.set_content(og); pg.evaluate("document.fonts.ready"); pg.wait_for_timeout(300)
    pg.screenshot(path=str(IMG / "og-brasis.png"))
    for nome, tam, pad, raio, red in [("favicon-32.png", 32, 4, 5, True), ("apple-touch-icon.png", 180, 36, 0, False), ("simbolo-512.png", 512, 96, 0, False)]:
        pg.set_viewport_size({"width": tam, "height": tam})
        pg.set_content(icone(tam, pad, raio, red))
        pg.screenshot(path=str(IMG / nome), omit_background=True)
    b.close()
print("Imagens geradas em", IMG)
